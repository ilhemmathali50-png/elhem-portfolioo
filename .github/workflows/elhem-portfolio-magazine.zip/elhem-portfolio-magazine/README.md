# Elhem Matheli — Portfolio Magazine

Site statique responsive avec animation de feuilletage, navigation tactile et clavier.

## Test
Ouvrir `index.html` dans un navigateur ou lancer `python -m http.server 8000` dans ce dossier.

## GitHub Pages
Créer un dépôt public indépendant, importer `index.html` et `assets/`, puis Settings → Pages → Deploy from a branch → main / root.

Les visuels ont été optimisés au format WebP à partir des images fournies. Les originaux ne sont pas modifiés.
